# -*- coding: UTF-8 -*-
from Plugins.Plugin import PluginDescriptor
from Plugins.Extensions.MultiStalker.ui.Launcher import MultiStalkerLauncher
from Plugins.Extensions.MultiStalker.commons.commons import conf
from enigma import addFont

addFont("/usr/lib/enigma2/python/Plugins/Extensions/MultiStalker/assets/fonts/google-icons.ttf", "Icons", 90, 1)
addFont("/usr/lib/enigma2/python/Plugins/Extensions/MultiStalker/assets/fonts/OpenSans-Regular.ttf", "Rg", 90, 1)
addFont("/usr/lib/enigma2/python/Plugins/Extensions/MultiStalker/assets/fonts/font_default.otf", "ArabicFont", 100, 1)
		
def main(session, **kwargs):
	session.open(MultiStalkerLauncher)
 
def showInmenu(menuid, **kwargs):
    if menuid == "mainmenu":
        return [("Multi-Stalker", main, "Multi-Stalker", 1)]
    else:
        return []

def Plugins(**kwargs):
	Descriptors=[]
	if conf.mainmenu.value:
		Descriptors.append(PluginDescriptor(where=[PluginDescriptor.WHERE_MENU], fnc=showInmenu))
	Descriptors.append(PluginDescriptor(name="Multi-Stalker", where=PluginDescriptor.WHERE_EXTENSIONSMENU, fnc=main))
	Descriptors.append(PluginDescriptor(name='Multi-Stalker', description='Multi-Stalker Portal By ZIKO', where=PluginDescriptor.WHERE_PLUGINMENU, fnc=main, icon='icon.png'))
	return Descriptors